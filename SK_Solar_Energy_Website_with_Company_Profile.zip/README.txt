SK SOLAR ENERGY WEBSITE
Files:
- index.html: responsive one-page company website

To preview:
1. Open index.html in a browser.
2. To publish, upload index.html to a web host (for example, GitHub Pages, Netlify, or your domain hosting).

Before publishing, verify:
- Contact person's spelling and phone number.
- Whether all listed services are currently offered.
- Service areas and address.
- Add your official business email, domain, real project photos, and verified registrations when available.

Important: This is a brand website draft. It does not claim SK Solar Energy is a Private Limited company or an approved government vendor.
